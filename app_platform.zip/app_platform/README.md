# app_platform
一个简易的app托管 原生h5页面
