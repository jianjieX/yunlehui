Page({
  data:{
      detailgood:{},
      listgood:[{
    "id": 101001,
    "name": "kkkkkZespri佳沛新西兰阳光金奇异果6个92-114g/个(北京)",
    "price": "111.0",
    "type": "3.3kg/箱",
    "pic_url": "http://img14.yiguoimg.com/e/ad/2016/160914/585749449477366062_260x320.jpg"
}, {
    "id": 101002,
    "name": "智利蓝莓2盒（约125g/盒）",
    "pic_url": "http://img09.yiguoimg.com/e/ad/2016/161011/585749449909281099_260x320.jpg",
    "price": "177.0",
    "type": "3.3kg/箱"
}, {
    "id": 101003,
    "name": "澳大利亚脐橙12个约160g/个(北京)",
    "price": "178.0",
    "type": "3.3kg/箱",
    "pic_url": "http://img12.yiguoimg.com/e/ad/2016/160914/585749449480249646_260x320.jpg"
}, {
    "id": 102001,
    "name": "Zespri佳沛新西兰阳光金奇异果6个92-114g/个(北京)",
    "price": "172.0",
    "type": "3.3kg/箱",
    "pic_url": "http://img14.yiguoimg.com/e/ad/2016/160914/585749449477366062_260x320.jpg"
}, {
    "id": 102002,
    "name": "智利蓝莓2盒（约125g/盒）",
    "pic_url": "http://img09.yiguoimg.com/e/ad/2016/161011/585749449909281099_260x320.jpg",
    "price": "171.0",
    "type": "3.3kg/箱"
}, {
    "id": 102003,
    "name": "澳大利亚脐橙12个约160g/个(北京)",
    "price": "174.0",
    "type": "3.3kg/箱",
    "pic_url": "http://img12.yiguoimg.com/e/ad/2016/160914/585749449480249646_260x320.jpg"
}, {
    "id": 103001,
    "name": "Zespri佳沛新西兰阳光金奇异果6个92-114g/个(北京)",
    "price": "177.0",
    "type": "3.3kg/箱",
    "pic_url": "http://img14.yiguoimg.com/e/ad/2016/160914/585749449477366062_260x320.jpg"
}, {
    "id": 103002,
    "name": "智利蓝莓2盒（约125g/盒）",
    "pic_url": "http://img09.yiguoimg.com/e/ad/2016/161011/585749449909281099_260x320.jpg",
    "price": "173.0",
    "type": "3.3kg/箱"
}, {
    "id": 103003,
    "name": "澳大利亚脐橙12个约160g/个(北京)",
    "price": "169.0",
    "type": "3.3kg/箱",
    "pic_url": "http://img12.yiguoimg.com/e/ad/2016/160914/585749449480249646_260x320.jpg"
}, {
    "id": 201001,
    "name": "Zespri佳沛新西兰阳光金奇异果6个92-114g/个(北京)",
    "price": "159.0",
    "type": "3.3kg/箱",
    "pic_url": "http://img14.yiguoimg.com/e/ad/2016/160914/585749449477366062_260x320.jpg"
}, {
    "id": 201002,
    "name": "智利蓝莓2盒（约125g/盒）",
    "pic_url": "http://img09.yiguoimg.com/e/ad/2016/161011/585749449909281099_260x320.jpg",
    "price": "149.0",
    "type": "3.3kg/箱"
}, {
    "id": 202001,
    "name": "澳大利亚脐橙12个约160g/个(北京)",
    "price": "139.0",
    "type": "3.3kg/箱",
    "pic_url": "http://img12.yiguoimg.com/e/ad/2016/160914/585749449480249646_260x320.jpg"
}, {
    "id": 203001,
    "name": "Zespri佳沛新西兰阳光金奇异果6个92-114g/个(北京)",
    "price": "159.0",
    "type": "3.3kg/箱",
    "pic_url": "http://img14.yiguoimg.com/e/ad/2016/160914/585749449477366062_260x320.jpg"
}, {
    "id": 401001,
    "name": "智利蓝莓2盒（约125g/盒）",
    "pic_url": "http://img09.yiguoimg.com/e/ad/2016/161011/585749449909281099_260x320.jpg",
    "price": "181.0",
    "type": "3.3kg/箱"
}, {
    "id": 101001,
    "name": "澳大利亚脐橙12个约160g/个(北京)",
    "price": "180.0",
    "type": "3.3kg/箱",
    "pic_url": "http://img12.yiguoimg.com/e/ad/2016/160914/585749449480249646_260x320.jpg"
}],
 hotgoods:[
      {
        "more_pic":"http://img10.yiguoimg.com/e/ad/2016/161008/585749449862226248_778x303.jpg"
      },{
        "more_pic":"http://img14.yiguoimg.com/e/ad/2016/160929/585749449767461181_778x303.jpg"
      },{
        "more_pic":"http://img12.yiguoimg.com/e/ad/2016/161009/585749449871663433_778x303.jpg"
      },{
        "more_pic":"http://img10.yiguoimg.com/e/ad/2016/161008/585749449862226248_778x303.jpg"
      },{
        "more_pic":"http://img14.yiguoimg.com/e/ad/2016/160929/585749449767461181_778x303.jpg"
      },{
        "more_pic":"http://img12.yiguoimg.com/e/ad/2016/161009/585749449871663433_778x303.jpg"
      },{
        "more_pic":"http://img10.yiguoimg.com/e/ad/2016/161008/585749449862226248_778x303.jpg"
      },{
        "more_pic":"http://img14.yiguoimg.com/e/ad/2016/160929/585749449767461181_778x303.jpg"
      },{
        "more_pic":"http://img12.yiguoimg.com/e/ad/2016/161009/585749449871663433_778x303.jpg"
      },{
        "more_pic":"http://img10.yiguoimg.com/e/ad/2016/161008/585749449862226248_778x303.jpg"
      }
    ],
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var  id=options.id;
    let list=this.data.listgood;
    var that=this;
    list.forEach(function(arr){
      console.log(arr.id.toString())
      console.log(id)
      if(id==arr.id){
        that.setData({
          detailgood:arr
        })
      }
    })
    console.log(this.data.detailgood)
  },

  onReady:function(){
 
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})
