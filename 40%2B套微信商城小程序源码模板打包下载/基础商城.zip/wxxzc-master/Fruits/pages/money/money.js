//我的钱包页面
//获取应用实例
var app=getApp()
Page({
    data:{
         cate_src: [
      {
        mode: 'scaleToFill',
        text: '我的余额',
        picture: '../../images/ye.png',
      },
      {
        mode: 'scaleToFill',
        text: '我的佣金',
        picture: '../../images/yj.png',
      },
      {
        mode: 'scaleToFill',
       text: '我的分红',
        picture: '../../images/qb.png',
      },
    ],
    },
})
