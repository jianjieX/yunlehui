//index.js


Page({
    data:{
        lunbo_src: [
      '../../images/list_banner.jpg',
      '../../images/list_banner.jpg',
      '../../images/list_banner.jpg'
    ],
    
    indicatorDots: true,
    autoplay: true,
    interval: 5000,
    duration: 1000,
    store_src: [
      '../../images/bb.jpg',
      '../../images/bb.jpg',
      '../../images/bb.jpg'
    ],

        
       
       
    }
  
    
    

});

