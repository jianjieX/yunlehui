//获取应用实例
var app = getApp()
Page({
    data:{
        cate_src: [
      {
        mode: 'scaleToFill',
        text: '我的排名',
        card:'身份：奥斯达',
        picture: '../../images/tx.png',
      },
      {
        mode: 'scaleToFill',
        text: '我的排名',
        card:'身份：奥斯达',
        picture: '../../images/tx.png',
      },
      {
        mode: 'scaleToFill',
       text: '我的排名',
        card:'身份：奥斯达',
        picture: '../../images/tx.png',
      },
      {
        mode: 'scaleToFill',
        text: '我的排名',
        card:'身份：奥斯达',
        picture: '../../images/tx.png',
      },
        ],
    },
})