export const rootUrl2 = 'http://www.360blj.com/'
export const rootUrl = `${rootUrl2}mobile`;