Page({
    onReady : function(){
        console.log('onReady')
    }
});