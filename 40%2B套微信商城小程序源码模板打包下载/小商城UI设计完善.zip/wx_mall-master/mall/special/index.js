//获取应用实例
var app = getApp();

Page({
    data: {
        special : [
            {
                url : "../../pages/wx/index",
                img : "http://o86ac3exs.bkt.clouddn.com/89336def-f1f5-4663-99ad-5a77a1c358f4.jpg",
                name: "伊滋来进口牛排系列",
                time: "2016-10-10"
            },
            {
                url : "../../pages/wx/index",
                img : "http://o86ac3exs.bkt.clouddn.com/fe0ac8a8-f4dd-43cc-88bd-d85864b7cb0d.jpg",
                name: "休闲零食",
                time: "2016-10-10"
            },
            {
                url : "../../pages/wx/index",
                img : "http://o86ac3exs.bkt.clouddn.com/9c691f1d-b3c3-4d1d-99b5-142d797db4e3.jpg",
                name: "水果系列",
                time: "2016-10-10"
            },
            {
                url : "../../pages/wx/index",
                img : "http://o86ac3exs.bkt.clouddn.com/8095d7d8-d1bf-4697-8fa3-2e7890541e50.jpg",
                name: "土豪盛宴",
                time: "2016-10-10"
            }
        ]
    }

});