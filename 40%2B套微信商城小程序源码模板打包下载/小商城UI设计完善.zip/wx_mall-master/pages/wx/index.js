//获取应用实例
var app = getApp();

Page({
    data : {
        items: [{
            message: 'foo',
            time   : '一分钟前'
        },{
            message: 'foo',
            time   : '23:23'
        },{
            message: 'foo',
            time   : '一天前'
        },{
            message: 'foo',
            time   : '昨天'
        },{
            message: 'foo',
            time   : '昨天'
        },{
            message: 'foo',
            time   : '昨天'
        },{
            message: 'foo',
            time   : '昨天'
        },{
            message: 'foo',
            time   : '昨天'
        },{
            message: 'foo',
            time   : '昨天'
        },{
            message: 'foo',
            time   : '昨天'
        },{
            message: 'foo',
            time   : '昨天'
        },{
            message: 'foo',
            time   : '昨天'
        }]
    },
    massage_info : function(event){
        /*跳转页面*/
        /*wx.navigateTo({
            url: '../index/index'
        });*/
    }
});