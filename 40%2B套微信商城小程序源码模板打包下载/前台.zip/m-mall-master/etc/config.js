export default {
	basePath: 'https://www.skyvow.cn/api', 
	fileBasePath: 'https://www.skyvow.cn/', 
}