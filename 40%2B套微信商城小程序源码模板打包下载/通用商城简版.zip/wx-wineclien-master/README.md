# wx-wineclien
微信小程序

首次开发，模仿一个商城类app，持续更新中

<img src="./pages/resource/ex.gif"/>