小程序商城demo，使用开发者工具调试。  
<img src = "image/demo.png" style = "text-align: center;display: block"/>    
<img src = "image/demo1.png" style = "text-align: center;display: block"/>    
<img src = "image/demo2.png" style = "text-align: center;display: block"/>    