App({
  onShow: function() {
    wx.login({
    });

  },
  onHide: function() {
  },
  globalData: {}
})

